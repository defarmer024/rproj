
There are communs with no values at all. We drop thes columns.

```{r}
missing11 <- pro.df11 %>% miss_var_summary()

# Create a vector of variables with all missing values
na.cols.remove11 <- missing11[missing11$n_miss==720,]$variable

## Select columns without missing from the data
pro.df11 <- pro.df11 %>% select(-na.cols.remove11)

## Replace the remaing missing values with the mean of the observed records
pro.df11 <- impute_mean_all(pro.df11)
```

```{r}
pro.df11 %>% miss_var_summary()
```
```{r}
pro.df11 %>% miss_var_summary()
```
There are communs with no values at all. We drop thes columns.

```{r}
missing11 <- pro.df11 %>% miss_var_summary()

# Create a vector of variables with all missing values
na.cols.remove11 <- missing11[missing11$n_miss==720,]$variable

## Select columns without missing from the data
pro.df11 <- pro.df11 %>% select(-na.cols.remove11)

## Replace the remaing missing values with the mean of the observed records
pro.df11 <- impute_mean_all(pro.df11)
```



```{r}
pro.df12 %>% miss_var_summary()
```
There are some columns with no values at all.


## Create a data frame of summarry of missing values
missing12 <- pro.df12 %>% miss_var_summary()

# Create a vector of variables with all missing values
na.cols.remove12 <- missing12[missing12$n_miss==744,]$variable

## Select data without collumns with no data
pro.df12 <- pro.df12 %>% select(-na.cols.remove12)

## Replace the remaing missing values with the mean of the observed records
pro.df12 <- impute_mean_all(pro.df12)

pro.df12 %>% miss_var_summary()
```

## Flags
Flags in the data have been represented with - -999,999,NoData,1800,109999

## November data
# Date
levels(pro.df11$day) <- c(levels(pro.df11$day),25)
pro.df11[pro.df11$day==999,"day"] = as.factor(25)

#Temperature
pro.df11[pro.df11$temp_u_fffd_c%in%c(-999,999,1800,109999),"temp_u_fffd_c"] = NA

#Stn Press (kPa)
pro.df11[pro.df11$stn_press_k_pa>=100000,"stn_press_k_pa"] = pro.df11[pro.df11$stn_press_k_pa>=100000,"stn_press_k_pa"]/1000
pro.df11[(pro.df11$stn_press_k_pa>=1000 & pro.df11$stn_press_k_pa<10000),"stn_press_k_pa"]/10
pro.df11[(pro.df11$stn_press_k_pa>=10000 & pro.df11$stn_press_k_pa<100000),"stn_press_k_pa"] = pro.df11[(pro.df11$stn_press_k_pa>=10000 & pro.df11$stn_press_k_pa<100000),"stn_press_k_pa"]/100

#Wind Dir (10s deg)
pro.df11[pro.df11$wind_dir_10s_deg>=50,"wind_dir_10s_deg"]=NA


```




```{r}
skim(df12)
```

```{r}
library(patchwork)
library(hrbrthemes)
data <- data.frame(
    day = as.Date("2019-01-01") + 0:99,
    temperature = runif(100) + seq(1,100)^2.5 / 10000,
    price = runif(100) + seq(100,1)^1.5 / 10
)

# Most basic line chart
p1 <- ggplot(data, aes(x=day, y=temperature)) +
    geom_line(color="#69b3a2", size=2) +
    ggtitle("Temperature: range 1-10") +
    theme_ipsum()

p2 <- ggplot(data, aes(x=day, y=price)) +
    geom_line(color="grey",size=2) +
    ggtitle("Price: range 1-100") +
    theme_ipsum()

# Display both charts side by side thanks to the patchwork package
p1 + p2
```
```{r}
x <- 1:10
y1 <- x*x
y2  <- 2*y1

# Create a basic stair steps plot 
plot(x, y1, type = "S")
# Show both points and line
plot(x, y1, type = "b", pch = 19, 
     col = "red", xlab = "x", ylab = "y")
```

```{r}
set.seed(1234)
x <- rnorm(120)
d <-.07
y <- cumsum(x+d)*-1

my.ts <- ts(y, start=c(2007, 1), end=c(2017, 12), frequency=12)  
tsp = attributes(my.ts)$tsp

dates = seq(as.Date("2007-01-01"), by = "month", along = my.ts)

plot(my.ts, xaxt = "n", main= "Plotting outcome over time",
     ylab="outcome", xlab="time")
axis(1, at = seq(tsp[1], tsp[2], along = my.ts), labels = format(dates, "%Y-%m"))
abline(v=2012, col="blue", lty=2, lwd=2)
```

